# from config.celery import app as celery_app

# # from django.apps import registry
# __all__ = ("celery_app",)
