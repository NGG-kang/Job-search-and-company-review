from bs4 import BeautifulSoup
import requests
import re
from crawling.models import Saramin
from crawling.functions.proxy import proxies
import random


def get_saramin_company(name):
    page = 1
    while True:
        resq = requests.get(
            f"https://www.saramin.co.kr/zf_user/search/company?searchword={name}&page={page}&searchType=search&pageCount=30&mainSearch=n#company_info",
            proxies=proxies,
        )
        soup = BeautifulSoup(resq.content, "lxml")
        search_list = soup.find_all("div", class_="item_corp")
        if not search_list:
            break
        while True:
            try:
                for company in search_list:

                    corp_name = company.find("h2", class_="corp_name")
                    name = corp_name.find("a")
                    url = name["href"]
                    name = name.text.strip()

                    company_pk = url.split("csn=")[-1]
                    data = {}
                    print(url)
                    corp_info = company.find("div", class_="corp_info")
                    data_list = corp_info.find_all("dl")
                    address = ""
                    for val in data_list:
                        key = val.find("dt").text.strip()
                        value = re.sub(r" {2,}", "", val.find("dd").text.strip())
                        if key == "기업주소":
                            address = value
                        data[key] = value
                    Saramin(
                        name=name, company_pk=company_pk, address=address, data=data
                    ).save()
                break
            except:
                pass

        page += 1
