from celery import shared_task
from crawling.models import JobPlanet, KreditJob
from crawling.functions.kreditjob_proxy import kreditjob_crawling
import json
from proxy import proxies
from bs4 import BeautifulSoup
import requests


def find_content(soup):
    company_name = (
        soup.find("div", {"class": "company_info_box"})
        .find("a")
        .text.replace("(주)", "")
    )
    data_json = soup.find("ul", {"class": "basic_info_more"})
    company_info = dict()
    for data in data_json:
        header = data.find("dt")
        content = data.find("dd")
        if header == -1:
            continue
        company_info[header.text.strip()] = content.text.strip()
    return (company_name, company_info)


@shared_task.task()
def jobplanet(name):
    print(
        "---------------------------------JOBPLNET----------------------------------------"
    )
    for _ in range(5):
        try:
            search_url = f"https://www.jobplanet.co.kr/autocomplete/autocomplete/suggest.json?term={name}"
            html = requests.get(search_url, allow_redirects=False, proxies=proxies)
            companies = json.loads(html.content)["companies"]
            if html.status_code in (302, 404):
                break
            # 업데이트 할거면 풀기
            # print(company_name)
            # print(company_info)
            for company in companies:
                name = company["name"]
                _id = company["id"]
                try:
                    j = JobPlanet.objects.get(company_pk=_id)
                    print("skip")
                    continue
                    j.name = company_name
                    j.data = company_info
                    j.save()
                except JobPlanet.DoesNotExist:
                    search_url = f"https://www.jobplanet.co.kr/companies/{_id}/landing/"
                    html = requests.get(
                        search_url, allow_redirects=False, proxies=proxies
                    )
                    soup = BeautifulSoup(html.content, "lxml")
                    company_name, company_info = find_content(soup)
                    print(company_name)
                    print(company_info)
                    JobPlanet(
                        name=company_name, company_pk=_id, data=company_info
                    ).save()
                print(
                    "---------------------------------JOBPLNET----------------------------------------"
                )
                kreditjob_crawling(company=company_name)
            break
        except Exception as e:
            print(e)


import re
from crawling.models import Saramin


@shared_task.task()
def get_saramin_company(name):
    page = 1
    while True:
        resq = requests.get(
            f"https://www.saramin.co.kr/zf_user/search/company?searchword={name}&page={page}&searchType=search&pageCount=30&mainSearch=n",
            proxies=proxies,
        )
        soup = BeautifulSoup(resq.content, "lxml")
        search_list = soup.find_all("div", class_="item_corp")
        if not search_list:
            break
        for company in search_list:
            try:
                corp_name = company.find("h2", class_="corp_name")
                name = corp_name.find("a")
                url = name["href"]
                name = name.text.strip()

                company_pk = url.split("csn=")[-1]
                try:
                    Saramin.objects.get(company_pk=company_pk)
                except Saramin.DoesNotExist:
                    data = {}
                    corp_info = company.find("div", class_="corp_info")
                    data_list = corp_info.find_all("dl")
                    address = ""
                    for val in data_list:
                        key = val.find("dt").text.strip()
                        value = re.sub(r" {2,}", "", val.find("dd").text.strip())
                        if key == "기업주소":
                            address = value
                        data[key] = value
                    Saramin(
                        name=name, company_pk=company_pk, address=address, data=data
                    ).save()
            except:
                pass
        page += 1
