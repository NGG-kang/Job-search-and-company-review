# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['company_review',
 'company_review.celery',
 'company_review.config',
 'company_review.config.settings',
 'company_review.crawling',
 'company_review.crawling.functions',
 'company_review.crawling.migrations',
 'company_review.crawling.search_jobs']

package_data = \
{'': ['*'],
 'company_review': ['.env/*',
                    'entrypoint/*',
                    'secrets/*',
                    'static/admin/css/*',
                    'static/admin/css/vendor/select2/*',
                    'static/admin/fonts/*',
                    'static/admin/img/*',
                    'static/admin/img/gis/*',
                    'static/admin/js/*',
                    'static/admin/js/admin/*',
                    'static/admin/js/vendor/jquery/*',
                    'static/admin/js/vendor/select2/*',
                    'static/admin/js/vendor/select2/i18n/*',
                    'static/admin/js/vendor/xregexp/*',
                    'static/bootstrap-5.1.3-dist/css/*',
                    'static/bootstrap-5.1.3-dist/js/*',
                    'static/css/*',
                    'static/debug_toolbar/css/*',
                    'static/debug_toolbar/js/*',
                    'static/dist/*',
                    'static/dist/img/*'],
 'company_review.crawling': ['templates/*']}

install_requires = \
['Django==3.2',
 'beautifulsoup4>=4.10.0,<5.0.0',
 'celery>=5.2.3,<6.0.0',
 'django-celery-beat>=2.2.1,<3.0.0',
 'django-celery-results>=2.2.0,<3.0.0',
 'django-crontab>=0.7.1,<0.8.0',
 'django-debug-toolbar>=3.2.4,<4.0.0',
 'django-htmx>=1.8.0,<2.0.0',
 'django-json-widget>=1.1.1,<2.0.0',
 'django-redis>=5.2.0,<6.0.0',
 'free-proxy>=1.0.6,<2.0.0',
 'ipython>=8.0.1,<9.0.0',
 'lxml>=4.7.1,<5.0.0',
 'psycopg2-binary>=2.9.3,<3.0.0',
 'requests>=2.27.1,<3.0.0',
 'soupsieve>=2.3.1,<3.0.0']

setup_kwargs = {
    'name': 'company-review',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'NGG-kang',
    'author_email': 'skarndrkd1222@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
