import requests
import time, json
import random
from crawling.models import KreditJob
from crawling.functions.proxy import proxies


jobdam_url = "https://www.kreditjob.com/board/"


def kreditjob_crawling(company):
    print(
        "---------------------------------KREDITJOB----------------------------------------"
    )
    search_url = f"https://www.kreditjob.com/api/search/autocomplete"
    search_response = json.loads(
        requests.get(
            search_url,
            params=[("q", company), ("index", 0), ("size", 5)],
            proxies=proxies,
        ).content
    )
    search_response = search_response.get("docs")

    print("-----------------검색---------------------")
    for search_company in search_response:
        print(search_company)
        CMPN_NM = search_company["CMPN_NM"]
        WKP_ADRS = search_company["WKP_ADRS"]
        PK_NM_HASH = search_company["PK_NM_HASH"]
        try:
            k = KreditJob.objects.get(company_pk=PK_NM_HASH)
            print("skip")
            break
            k.name = CMPN_NM
            k.address = WKP_ADRS
            k.company_base_content = company_base_content
            k.company_info_data = company_info_data
            k.company_jobdam = company_jobdam
            k.save()
        except KreditJob.DoesNotExist:
            while True:
                company_base_content = json.loads(
                    requests.get(
                        f"https://www.wanted.co.kr/api/v1/company_briefs?kreditjob_pk={PK_NM_HASH}",
                        proxies=proxies,
                    ).content
                )
                # POST
                # 기업 연봉포함 정보
                # data
                data = {"PK_NM_HASH": PK_NM_HASH}
                company_info_data = json.loads(
                    requests.post(
                        "https://www.kreditjob.com/api/company/companyPage",
                        data=data,
                        proxies=proxies,
                    ).content
                )
                # POST
                # 기업 잡담
                data = {"PK_NM_HASH": ["PK_NM_HASH", PK_NM_HASH]}
                company_jobdam = json.loads(
                    requests.post(
                        "https://www.kreditjob.com/api/jobdom/multiFilter/1/10",
                        data=data,
                        proxies=proxies,
                    ).content
                )
                # print("-----------------기업기본정보---------------------")
                # print(company_base_content)
                # print("-----------------기업연봉포함정보---------------------")
                # print(company_info_data)
                # print("-----------------기업잡담---------------------")
                # print(company_jobdam)

                print("-----------------기업기본정보---------------------")
                print(company_base_content)
                KreditJob(
                    name=CMPN_NM,
                    address=WKP_ADRS,
                    company_pk=PK_NM_HASH,
                    company_base_content=company_base_content,
                    company_info_data=company_info_data,
                    company_jobdam=company_jobdam,
                ).save()
                break
