from config.settings.base import *


STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR + "static/"
